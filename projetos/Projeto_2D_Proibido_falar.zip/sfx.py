import numpy as np, soundfile as sf, json
from scipy.signal import butter, sosfilt, fftconvolve
SR = 44100
TL = json.load(open('aud/timeline.json')); MK = TL['marks']
TOTAL = TL['marks']['end_speech'] + 4.6
N = int(TOTAL*SR)
rng = np.random.default_rng(7)

def bp(x, lo, hi): return sosfilt(butter(4, [lo, hi], 'band', fs=SR, output='sos'), x)
def lp(x, f): return sosfilt(butter(4, f, 'low', fs=SR, output='sos'), x)
def ir(dur, decay):
    t = np.arange(int(dur*SR))/SR
    return rng.standard_normal(len(t))*np.exp(-t/decay)*0.25

def clap(muffled=False):
    n = int(0.18*SR); t = np.arange(n)/SR
    x = np.zeros(n)
    for off in (0, 0.006, 0.012):   # multi-transient like real clap
        k = int(off*SR); m = n-k; tt = np.arange(m)/SR
        x[k:] += rng.standard_normal(m)*np.exp(-tt/0.011)
    x = bp(x, 700, 4500)
    if muffled: x = lp(x, 650)*2.2
    L = int(0.7*SR); r = fftconvolve(x, ir(0.5 if not muffled else 0.25, 0.12 if not muffled else 0.05))
    r = np.pad(r, (0, max(0, L-len(r))))[:L]
    x = r + np.pad(x, (0, L-n))
    return x/np.max(np.abs(x))

def whistle(dur=0.8, f=2700):
    t = np.arange(int(dur*SR))/SR
    fr = f + 120*np.sin(2*np.pi*28*t)
    x = np.sin(2*np.pi*np.cumsum(fr)/SR) + 0.15*rng.standard_normal(len(t))*0.3
    env = np.minimum(1, t/0.03)*np.minimum(1, (dur-t)/0.08)
    return x*env

def fiu():
    out = []
    for f0, f1, d in ((1400, 2600, 0.22), (1500, 900, 0.3)):
        t = np.arange(int(d*SR))/SR; fr = np.linspace(f0, f1, len(t))
        out.append(np.sin(2*np.pi*np.cumsum(fr)/SR)*np.sin(np.pi*t/d)); out.append(np.zeros(int(0.05*SR)))
    return np.concatenate(out)

def knock():
    n = int(0.25*SR); t = np.arange(n)/SR
    x = np.sin(2*np.pi*140*t)*np.exp(-t/0.03) + lp(rng.standard_normal(n), 900)*np.exp(-t/0.012)*1.5
    return x/np.max(np.abs(x))

def snore(dur=1.4):
    t = np.arange(int(dur*SR))/SR
    env = np.sin(np.pi*t/dur)**2
    buzz = np.sign(np.sin(2*np.pi*38*t))*0.6
    x = lp(rng.standard_normal(len(t))*0.6 + buzz, 500)*env
    return x/np.max(np.abs(x))

def creak(dur=0.7):
    t = np.arange(int(dur*SR))/SR
    fr = 300 + 180*np.sin(2*np.pi*1.3*t)
    pulses = (np.sin(2*np.pi*np.cumsum(fr/9)/SR) > 0.95).astype(float)
    x = bp(pulses + 0.05*rng.standard_normal(len(t)), 300, 2500)*np.sin(np.pi*t/dur)
    return x/np.max(np.abs(x))

fx = np.zeros(N)
def put(x, t, g):
    i = int(t*SR); j = min(N, i+len(x)); fx[i:j] += x[:j-i]*g

# scene times
def wt(word, after=0.0):
    for w, s, e in TL['words']:
        if s >= after and w.lower().startswith(word.lower()): return s
put(whistle(), 0.9, 0.20)
fg, _ = sf.read('aud/f.wav')
if fg.ndim > 1: fg = fg.mean(1)
faint = fftconvolve(lp(fg, 1800), ir(1.5, 0.5))[:len(fg)+SR]
faint /= np.max(np.abs(faint))
put(faint, MK['whisper1']+0.1, 0.16)
put(faint[int(0.0*SR):], MK['whisper1']+0.75, 0.10)
for st in (0.15, 0.45, 0.75): put(knock(), wt('Batindo')+st, 0.45)
put(snore(), wt('encostei')+1.5, 0.22)
put(creak(), wt('voltei'), 0.10)
# low drone under the foge part
d0 = MK['foge_start']-0.3; dd = MK['end_speech']-d0
tt = np.arange(int(dd*SR))/SR
drone = (np.sin(2*np.pi*55*tt) + 0.5*np.sin(2*np.pi*58.3*tt) + 0.3*lp(rng.standard_normal(len(tt)), 200))*np.minimum(1, tt/1.0)
put(drone/np.max(np.abs(drone)), d0, 0.13)
put(creak(1.2), MK['end_speech']-0.1, 0.16)
# sting when the eyes appear
tt = np.arange(int(2.5*SR))/SR
boom = np.sin(2*np.pi*45*tt*(1-0.2*tt))*np.exp(-tt/0.7) + lp(rng.standard_normal(len(tt)), 300)*np.exp(-tt/0.25)
put(boom/np.max(np.abs(boom)), MK['end_speech']+0.9, 0.7)
# trilha padrão (fixa para animações 2D/3D), em loop, ~12-13 dB abaixo da voz
import subprocess
raw = subprocess.run(['ffmpeg','-v','error','-i','trilha.mp3','-ac','1','-ar',str(SR),'-f','f32le','-'],capture_output=True).stdout
tr = np.frombuffer(raw, np.float32).astype(np.float64)
reps = int(np.ceil(N/len(tr)))
mus = np.tile(tr, reps)[:N]
fo = int(1.5*SR); mus[-fo:] *= np.linspace(1, 0, fo)
mus /= np.sqrt(np.mean(tr**2))  # normalize RMS
nar, _ = sf.read('aud/narr.wav')
if nar.ndim > 1: nar = nar.mean(1)
v = np.zeros(N); v[:len(nar)] = nar[:N]
# duck music under voice slightly: music level ~ -20 dB below voice peak
fogerev = np.zeros(N); i0=int(MK['foge_start']*SR); r = fftconvolve(fg, ir(1.2, 0.35)); r/=np.max(np.abs(r)); fogerev[i0:i0+len(r)] = r[:N-i0]
vr = np.sqrt(np.mean(v[np.abs(v)>0.01]**2))
mix = v*1.0 + mus*vr*10**(-12.5/20) + fx + fogerev*0.12
mix /= max(1.0, np.max(np.abs(mix))/0.95)
sf.write('mix_raw.wav', mix, SR)
print('ok')
