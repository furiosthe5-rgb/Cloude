import cairo, math, json, subprocess, sys, random

W, H, FPS = 1080, 1920, 30
import os; OUTDIR = os.environ.get('OUTDIR', 'stills')
TL = json.load(open('aud/timeline.json'))
MK = TL['marks']
OUT = '#2a2340'

# ---------------------------------------------------------------- helpers
def hx(c, a=1.0):
    c = c.lstrip('#'); return (int(c[0:2], 16)/255, int(c[2:4], 16)/255, int(c[4:6], 16)/255, a)

def setc(cr, c, a=1.0): cr.set_source_rgba(*hx(c, a))

def rrect(cr, x, y, w, h, r):
    r = min(r, w/2, h/2)
    cr.new_sub_path()
    cr.arc(x+w-r, y+r, r, -math.pi/2, 0); cr.arc(x+w-r, y+h-r, r, 0, math.pi/2)
    cr.arc(x+r, y+h-r, r, math.pi/2, math.pi); cr.arc(x+r, y+r, r, math.pi, 1.5*math.pi)
    cr.close_path()

def fs(cr, fill, lw=6, stroke=OUT):
    setc(cr, fill); cr.fill_preserve(); cr.set_line_width(lw); setc(cr, stroke); cr.stroke()

def circ(cr, x, y, r, fill, lw=6):
    cr.new_path(); cr.arc(x, y, r, 0, 2*math.pi); fs(cr, fill, lw)

def ell(cr, x, y, rx, ry, fill, lw=6):
    cr.save(); cr.translate(x, y); cr.scale(rx, ry); cr.new_path(); cr.arc(0, 0, 1, 0, 2*math.pi); cr.restore(); fs(cr, fill, lw)

def ease(x): x = max(0, min(1, x)); return x*x*(3-2*x)
def outback(x):
    x = max(0, min(1, x)); c1 = 1.70158; c3 = c1+1
    return 1 + c3*(x-1)**3 + c1*(x-1)**2

def text(cr, s, x, y, size, fill='#ffffff', font='Poppins', bold=True, lw=10, stroke=OUT, anchor='c', rot=0, alpha=1.0):
    cr.save()
    cr.select_font_face(font, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD if bold else cairo.FONT_WEIGHT_NORMAL)
    cr.set_font_size(size)
    ext = cr.text_extents(s)
    cr.translate(x, y); cr.rotate(rot)
    ox = -ext.x_bearing - ext.width/2 if anchor == 'c' else (-ext.x_bearing if anchor == 'l' else -ext.x_bearing-ext.width)
    oy = -ext.y_bearing - ext.height/2
    cr.move_to(ox, oy); cr.text_path(s)
    if lw:
        cr.set_line_join(cairo.LINE_JOIN_ROUND); cr.set_line_width(lw); setc(cr, stroke, alpha); cr.stroke_preserve()
    setc(cr, fill, alpha); cr.fill(); cr.new_path()
    cr.restore()
    return ext.x_advance

def text_w(cr, s, size, font='Poppins'):
    cr.select_font_face(font, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD); cr.set_font_size(size)
    return cr.text_extents(s).x_advance

def onoma(cr, s, x, y, size, lt, fill='#ffd23f', rot=-0.12, dur=None):
    """pop-in onomatopoeia"""
    k = outback(lt/0.18) if lt < 0.18 else 1.0
    a = 1.0
    if dur is not None and lt > dur-0.15: a = max(0, (dur-lt)/0.15)
    cr.save(); cr.translate(x, y); cr.scale(k, k)
    text(cr, s, 0, 0, size, fill, font='Anton', bold=False, lw=16, rot=rot, alpha=a)
    cr.restore()

def rings(cr, x, y, lt, color='#f3e3b5', n=3, maxr=330):
    for i in range(n):
        p = ((lt*0.9 + i/n) % 1.0)
        cr.new_path(); cr.arc(x, y, 40+p*maxr, 0, 2*math.pi)
        cr.set_line_width(7*(1-p)+1); setc(cr, color, 0.85*(1-p)); cr.stroke()

def tag(cr, s, x, y, lt, bg='#ffd23f', fg='#2a2340', size=58, rot=-0.04):
    k = outback(lt/0.25) if lt < 0.25 else 1.0
    w = text_w(cr, s, size) + 60; h = size*1.45
    cr.save(); cr.translate(x, y); cr.rotate(rot); cr.scale(k, k)
    rrect(cr, -w/2, -h/2, w, h, 22); fs(cr, bg, 7)
    text(cr, s, 0, 2, size, fg, lw=0)
    cr.restore()

# ---------------------------------------------------------------- characters
SKIN = '#f3c9a1'

def person(cr, x, y, s=1.0, shirt='#e2533b', pants='#2f3a66', hair='#7b4a2b', skin=SKIN,
           expr='neutral', arms=(15, -15), look=(0, 0), back=False, blink=False, hairstyle='spiky',
           mouth_open=0.0, cap=None, glasses=False, mustache=None, nightcap=None, flashlight=False,
           bob=0.0, lean=0.0, legs_walk=0.0, bowed=0.0, head_tilt=0.0, squash=0.0, shake=0.0, elbows=(0, 0), breath=0.0):
    cr.save(); cr.translate(x + shake, y + bob); cr.scale(s*(1+squash), s*(1-squash)); cr.rotate(lean)
    # legs
    for i, sx in enumerate((-42, 42)):
        sw = math.sin(legs_walk) * (18 if i == 0 else -18)
        cr.save(); cr.translate(sx, -175); cr.rotate(math.radians(sw))
        rrect(cr, -30, 0, 60, 160, 14); fs(cr, pants)
        ell(cr, 4 if sx > 0 else -4, 168, 46, 22, '#f4f4f6')
        cr.restore()
    cr.save(); cr.translate(0, -175); cr.rotate(bowed); cr.translate(0, 175)
    # back arm drawn behind for back view
    def arm(side, ang, elb=0.0):
        p0 = (122*side, -392)
        f1 = math.radians(ang); f2 = f1 + math.radians(elb)
        p1 = (p0[0] - math.sin(f1)*105, p0[1] + math.cos(f1)*105)
        p2 = (p1[0] - math.sin(f2)*92, p1[1] + math.cos(f2)*92)
        cr.new_path(); cr.move_to(*p0); cr.line_to(*p1); cr.line_to(*p2)
        cr.set_line_cap(cairo.LINE_CAP_ROUND); cr.set_line_join(cairo.LINE_JOIN_ROUND)
        cr.set_line_width(64); setc(cr, OUT); cr.stroke_preserve()
        cr.set_line_width(52); setc(cr, shirt); cr.stroke()
        if flashlight and side == 1:
            cr.save(); cr.translate(*p2); cr.rotate(f2)
            rrect(cr, -24, 0, 48, 78, 10); fs(cr, '#f2b630', 5)
            rrect(cr, -32, 66, 64, 30, 8); fs(cr, '#f7d15a', 5)
            cr.restore()
        circ(cr, p2[0], p2[1], 31, skin, 6)
    # torso
    rrect(cr, -125, -420, 250, 265, 46); fs(cr, shirt)
    if not back:
        rrect(cr, -45, -250, 90, 48, 12); cr.set_source_rgba(0, 0, 0, 0.0); fs(cr, shirt, 6)
    arm(-1, arms[0], elbows[0]); arm(1, arms[1], elbows[1])
    # head
    cr.save(); cr.translate(0, -420); cr.rotate(head_tilt); cr.translate(0, 420)
    hy = -545
    circ(cr, -122, hy+10, 26, skin); circ(cr, 122, hy+10, 26, skin)
    circ(cr, 0, hy, 128, skin)
    if back:
        cr.new_path(); cr.arc(0, hy, 128, 0, 2*math.pi); setc(cr, hair); cr.fill()
        cr.new_path(); cr.arc(0, hy, 128, 0, 2*math.pi); cr.set_line_width(6); setc(cr, OUT); cr.stroke()
    else:
        # cheeks
        setc(cr, '#ef8f8f', 0.55); cr.new_path(); cr.arc(-80, hy+45, 22, 0, 2*math.pi); cr.fill()
        cr.new_path(); cr.arc(80, hy+45, 22, 0, 2*math.pi); cr.fill()
        # eyes
        for ex in (-48, 48):
            if blink or expr == 'sleep':
                cr.new_path(); cr.arc(ex, hy-5, 26, 0.15*math.pi, 0.85*math.pi); cr.set_line_width(7); setc(cr, OUT); cr.stroke()
            else:
                er = 44 if expr in ('shock', 'scared') else 40
                ell(cr, ex, hy-10, er-4, er, '#ffffff', 5)
                ir = 18 if expr in ('shock', 'scared') else 26
                lx, ly = look
                circ(cr, ex+lx*10, hy-6+ly*10, ir, '#3f73d6', 0)
                circ(cr, ex+lx*10, hy-6+ly*10, ir*0.5, '#1b1530', 0)
                circ(cr, ex+lx*10+ir*0.35, hy-6+ly*10-ir*0.4, ir*0.28, '#ffffff', 0)
        # brows
        cr.set_line_width(9); setc(cr, OUT); cr.set_line_cap(cairo.LINE_CAP_ROUND)
        if expr in ('angry', 'determined'):
            for sgn in (-1, 1):
                cr.move_to(sgn*82, hy-70); cr.line_to(sgn*25, hy-52); cr.stroke()
        elif expr in ('worried', 'scared', 'confused'):
            for sgn in (-1, 1):
                if expr == 'confused' and sgn == 1:
                    cr.move_to(sgn*25, hy-78); cr.line_to(sgn*80, hy-70); cr.stroke()
                else:
                    cr.move_to(sgn*80, hy-66); cr.line_to(sgn*28, hy-80); cr.stroke()
        # mouth
        my = hy + 62
        if expr == 'happy':
            cr.new_path(); cr.move_to(-42, my-8); cr.curve_to(-30, my+50, 30, my+50, 42, my-8); cr.close_path(); fs(cr, '#7a2232', 5)
            cr.new_path(); cr.move_to(-30, my); cr.line_to(30, my); cr.line_to(28, my+8); cr.line_to(-28, my+8); cr.close_path(); setc(cr, '#ffffff'); cr.fill()
        elif expr in ('shock', 'scared') or mouth_open > 0.05:
            r = 20 if expr in ('shock', 'scared') else 8 + 16*mouth_open
            ell(cr, 0, my+8, r*0.8, r, '#7a2232', 5)
        elif expr == 'sleep':
            cr.new_path(); cr.arc(0, my-4, 14, 0.2*math.pi, 0.8*math.pi); cr.set_line_width(6); cr.stroke()
        elif expr in ('worried', 'confused', 'determined', 'angry'):
            cr.new_path(); cr.move_to(-22, my+10); cr.curve_to(-8, my-2, 8, my-2, 22, my+12); cr.set_line_width(6); cr.stroke()
        else:
            cr.new_path(); cr.arc(0, my-12, 26, 0.25*math.pi, 0.75*math.pi); cr.set_line_width(6); cr.stroke()
        if expr in ('worried', 'scared'):
            # sweat drop
            cr.new_path(); cr.move_to(130, hy-90); cr.curve_to(115, hy-55, 120, hy-35, 132, hy-35); cr.curve_to(146, hy-35, 150, hy-55, 130, hy-90)
            fs(cr, '#8fd3ff', 4)
        if glasses:
            cr.set_line_width(7); setc(cr, '#d1453b')
            for ex in (-48, 48):
                cr.new_path(); cr.arc(ex, hy-8, 50, 0, 2*math.pi); cr.stroke()
            cr.move_to(-2, hy-10); cr.line_to(2, hy-10); cr.stroke()
        if mustache:
            for sgn in (-1, 1):
                cr.new_path(); cr.save(); cr.translate(sgn*30, hy+42); cr.scale(36, 16); cr.arc(0, 0, 1, 0, 2*math.pi); cr.restore()
                fs(cr, mustache, 4)
    # hair
    if hairstyle == 'spiky' and not back:
        cr.new_path()
        cr.move_to(-128, hy-10)
        cr.curve_to(-135, hy-120, -70, hy-150, 0, hy-140)
        cr.line_to(10, hy-200); cr.line_to(35, hy-140); cr.line_to(75, hy-185); cr.line_to(80, hy-125)
        cr.curve_to(120, hy-110, 132, hy-60, 128, hy-20)
        cr.curve_to(100, hy-80, 40, hy-95, -10, hy-85)
        cr.curve_to(-60, hy-80, -105, hy-60, -128, hy-10)
        cr.close_path(); fs(cr, hair, 6)
    elif hairstyle == 'spiky' and back:
        cr.new_path(); cr.move_to(-20, hy-125); cr.line_to(5, hy-195); cr.line_to(35, hy-125); cr.line_to(70, hy-175); cr.line_to(85, hy-110); cr.close_path(); fs(cr, hair, 6)
    elif hairstyle == 'old':
        for sgn in (-1, 1):
            cr.new_path(); cr.save(); cr.translate(sgn*112, hy-30); cr.scale(34, 52); cr.arc(0, 0, 1, 0, 2*math.pi); cr.restore(); fs(cr, '#eeeeee', 5)
    elif hairstyle == 'bob':
        cr.new_path(); cr.arc(0, hy-10, 140, math.pi*0.95, math.pi*2.05); cr.line_to(140, hy+40); cr.line_to(95, hy+40); cr.line_to(95, hy-60)
        cr.curve_to(40, hy-95, -40, hy-95, -95, hy-60); cr.line_to(-95, hy+40); cr.line_to(-140, hy+40); cr.close_path(); fs(cr, hair, 6)
    elif hairstyle == 'short':
        cr.new_path(); cr.arc(0, hy, 130, math.pi*1.02, math.pi*1.98); cr.curve_to(90, hy-80, -90, hy-80, -128, hy-20); cr.close_path(); fs(cr, hair, 6)
    if cap:
        cr.new_path(); cr.arc(0, hy-40, 132, math.pi, 2*math.pi); cr.close_path(); fs(cr, cap, 6)
        rrect(cr, -150, hy-52, 300, 34, 14); fs(cr, cap, 6)
    if nightcap:
        cr.new_path(); cr.move_to(-135, hy-80); cr.curve_to(-120, hy-240, 120, hy-270, 175, hy-150)
        cr.curve_to(150, hy-120, 140, hy-100, 135, hy-80); cr.close_path(); fs(cr, nightcap, 6)
        rrect(cr, -150, hy-118, 300, 50, 25); fs(cr, '#ffffff', 6)
        circ(cr, 182, hy-142, 26, '#ffffff', 5)
    cr.restore()
    cr.restore()
    cr.restore()

def kid(cr, x, y, s=1.0, **kw):
    person(cr, x, y, s, **kw)

def blink_at(t, seed=0):
    p = (t + seed*1.37) % 3.1
    return p < 0.12

# ---------------------------------------------------------------- backgrounds
def bg_fill(cr, c1, c2=None):
    if c2:
        g = cairo.LinearGradient(0, 0, 0, H); g.add_color_stop_rgba(0, *hx(c1)); g.add_color_stop_rgba(1, *hx(c2)); cr.set_source(g)
    else: setc(cr, c1)
    cr.rectangle(-200, -200, W+400, H+400); cr.fill()

def cloud(cr, x, y, s):
    setc(cr, '#ffffff', 0.95)
    for dx, dy, r in ((0, 0, 40), (45, -18, 52), (95, 0, 40), (48, 12, 42)):
        cr.new_path(); cr.arc(x+dx*s, y+dy*s, r*s, 0, 2*math.pi); cr.fill()

HOUSE_COLS = ['#f6a6a6', '#9ed2c6', '#f7d488', '#b9a7e8', '#8fc3f0', '#f3b38a', '#c9e3a0', '#f2a7c9']

def town_bg(cr, t, night=False):
    bg_fill(cr, '#8fd0f5', '#d7f0fb') if not night else bg_fill(cr, '#1d2050', '#3a3170')
    for i, (cx, cy, s) in enumerate(((120, 160, 1.3), (520, 110, 1.0), (860, 200, 1.5))):
        if night: continue
        cloud(cr, (cx + t*12*(i+1)) % 1300 - 120, cy, s)
    # birds
    if night:
        circ(cr, 860, 230, 60, '#f7e7a1', 0); circ(cr, 832, 212, 58, '#1d2050', 0)
        for sx, sy in ((120, 150), (300, 260), (520, 120), (700, 330), (980, 420), (420, 400)): circ(cr, sx, sy, 5, '#ffffff', 0)
    if not night:
        cr.set_line_width(5); setc(cr, '#3b3550')
        for bx, by in ((700, 300), (760, 270), (300, 330)):
            bx2 = bx + t*40
            cr.move_to(bx2-18, by); cr.curve_to(bx2-8, by-12, bx2-2, by-6, bx2, by); cr.curve_to(bx2+2, by-6, bx2+8, by-12, bx2+18, by); cr.stroke()
    random.seed(4)
    x = -40
    while x < W+40:
        w = random.randint(170, 240); h = random.randint(380, 560); c = random.choice(HOUSE_COLS)
        top = 1100 - h
        rrect(cr, x, top, w, h+200, 6); fs(cr, c, 6)
        # roof
        cr.new_path(); cr.move_to(x-12, top+4); cr.line_to(x+w/2, top-70); cr.line_to(x+w+12, top+4); cr.close_path(); fs(cr, '#c4574a', 6)
        for wy in range(top+50, 1060, 120):
            for wx in (x+30, x+w-90):
                rrect(cr, wx, wy, 60, 75, 6); fs(cr, '#ffe9a8' if night else '#e8f6ff', 5)
                cr.set_line_width(4); setc(cr, OUT); cr.move_to(wx+30, wy); cr.line_to(wx+30, wy+75); cr.stroke()
        x += w + 8
    # bunting
    cr.set_line_width(4); setc(cr, '#3b3550'); cr.move_to(0, 620); cr.curve_to(300, 700, 700, 700, W, 610); cr.stroke()
    cols = ['#e2533b', '#f7c548', '#3fa7d6', '#59cd90']
    for i in range(14):
        u = i/13; bx = u*W; by = 620 + math.sin(u*math.pi)*70
        cr.new_path(); cr.move_to(bx-22, by); cr.line_to(bx+22, by); cr.line_to(bx, by+44); cr.close_path(); fs(cr, cols[i % 4], 3)
    # floor
    setc(cr, '#e9d3b0'); cr.rectangle(-200, 1100, W+400, 1100); cr.fill()
    cr.set_line_width(3); setc(cr, '#cdb48e')
    for i in range(-10, 20):
        cr.move_to(W/2 + i*60, 1100); cr.line_to(W/2 + i*220, H+200); cr.stroke()
    for yy in (1180, 1290, 1430, 1620):
        cr.move_to(-200, yy); cr.line_to(W+200, yy); cr.stroke()

def clap_icon(cr, x, y, s, crossed=True):
    cr.save(); cr.translate(x, y); cr.scale(s, s)
    circ(cr, 0, 0, 120, '#ffffff', 10)
    for sgn in (-1, 1):
        cr.save(); cr.rotate(sgn*0.28)
        rrect(cr, -32 + sgn*16, -70, 64, 120, 30); fs(cr, SKIN, 6)
        cr.restore()
    if crossed:
        cr.new_path(); cr.arc(0, 0, 120, 0, 2*math.pi); cr.set_line_width(20); setc(cr, '#e23b3b'); cr.stroke()
        cr.move_to(-85, -85); cr.line_to(85, 85); cr.set_line_width(20); cr.stroke()
    cr.restore()

def sign(cr, x, y, lt):
    rrect(cr, x-10, y+150, 20, 330, 6); fs(cr, '#8a6a4a')
    rrect(cr, x-230, y-180, 460, 340, 24); fs(cr, '#fffaf0', 9)
    rrect(cr, x-210, y-160, 420, 300, 16); cr.set_line_width(5); setc(cr, '#e23b3b'); cr.stroke()
    clap_icon(cr, x, y-50, 0.72)
    text(cr, 'PROIBIDO', x, y+68, 54, '#e23b3b', lw=0)
    text(cr, 'BATER PALMAS', x, y+118, 36, OUT, lw=0)

def stage_bg(cr, t):
    bg_fill(cr, '#2d2350', '#3d2c5e')
    # curtains
    for sgn in (-1, 1):
        cr.new_path(); x0 = 0 if sgn < 0 else W
        cr.move_to(x0, 0); cr.line_to(x0 - sgn*-200, 0); cr.curve_to(x0+sgn*-160, 600, x0+sgn*-120, 1100, x0+sgn*-60, 1350); cr.line_to(x0, 1350); cr.close_path()
        fs(cr, '#a8323b', 6)
    # spotlight
    g = cairo.LinearGradient(0, 0, 0, 1400); g.add_color_stop_rgba(0, 1, 1, 0.85, 0.30); g.add_color_stop_rgba(1, 1, 1, 0.85, 0.06)
    cr.new_path(); cr.move_to(W/2-60, 120); cr.line_to(W/2+60, 120); cr.line_to(W/2+330, 1350); cr.line_to(W/2-330, 1350); cr.close_path(); cr.set_source(g); cr.fill()
    # floor
    setc(cr, '#8b5a34'); cr.rectangle(-200, 1300, W+400, 900); cr.fill()
    cr.set_line_width(4); setc(cr, '#6f4426')
    for yy in range(1340, H+200, 70): cr.move_to(-200, yy); cr.line_to(W+200, yy); cr.stroke()
    ell(cr, W/2, 1350, 330, 60, '#f5e7b0', 0);
    setc(cr, '#f5e7b0', 0.0)
    # banner
    rrect(cr, 210, 60, 660, 120, 20); fs(cr, '#ffd23f', 7)
    text(cr, 'SHOW DE TALENTOS', W/2, 120, 56, OUT, lw=0)
    for i in range(9):
        on = (int(t*6)+i) % 2 == 0
        circ(cr, 250 + i*72, 215, 11, '#fff3b0' if on else '#b39b4a', 0)

def room_bg(cr, t, clock='23:58', lit=False):
    bg_fill(cr, '#2a2d5e' if not lit else '#3a3d7e', '#20224a')
    # window
    rrect(cr, 620, 190, 330, 380, 14); fs(cr, '#151a3a', 8)
    circ(cr, 860, 280, 46, '#f7e7a1', 0); circ(cr, 835, 265, 44, '#151a3a', 0)
    for sx, sy in ((680, 260), (720, 420), (900, 470), (780, 330)):
        circ(cr, sx, sy, 5, '#ffffff', 0)
    cr.set_line_width(8); setc(cr, OUT); cr.move_to(785, 190); cr.line_to(785, 570); cr.move_to(620, 380); cr.line_to(950, 380); cr.stroke()
    # poster
    rrect(cr, 110, 230, 230, 300, 8); fs(cr, '#e9c46a', 6)
    cr.new_path(); cr.move_to(225, 280); cr.line_to(255, 400); cr.line_to(195, 400); cr.close_path(); fs(cr, '#d1453b', 4)
    # floor
    setc(cr, '#3a2f5a'); cr.rectangle(-200, 1380, W+400, 800); cr.fill()
    # clock on nightstand
    rrect(cr, 60, 1050, 260, 330, 12); fs(cr, '#6b4a3a')
    rrect(cr, 90, 960, 200, 100, 14); fs(cr, '#1b1530', 6)
    text(cr, clock, 190, 1010, 52, '#ff5a5a', lw=0)

def bed(cr, x, y, front=True):
    rrect(cr, x-360, y-520, 90, 640, 24); fs(cr, '#7b5236')
    rrect(cr, x-300, y-200, 700, 160, 30); fs(cr, '#f0f2fa')
    rrect(cr, x-290, y-330, 230, 140, 50); fs(cr, '#e8ecf8')
    rrect(cr, x-160, y-230, 600, 220, 40); fs(cr, '#3c64c8')
    rrect(cr, x-320, y-40, 760, 110, 16); fs(cr, '#7b5236')

def grid_map(cr, t, crossed_until, mine_glow=False, crosses=None, label=None, lt=0):
    _grid(cr, t, crossed_until, mine_glow)
    cols, rows, cw, ch = 5, 9, 230, 205
    ox, oy = (W - cols*cw)/2 + 10, 70
    order = []
    for r in range(rows):
        for c in (range(cols) if r % 2 == 0 else range(cols-1, -1, -1)): order.append((c, r))
    if mine_glow:
        c, r = 2, 4; px, py = ox+c*cw+cw/2-5, oy+r*ch+ch/2 + 120
    else:
        f = min(crossed_until, len(order)-1.001); i = int(f); u = f - i
        (c0, r0), (c1, r1) = order[i], order[min(i+1, len(order)-1)]
        px = ox + (c0 + (c1-c0)*u)*cw + cw/2 - 5; py = oy + (r0 + (r1-r0)*u)*ch + ch/2 + 120
    K(cr, px, py, 0.3, t, lt, ('determined', 'worried', 'confused') if not mine_glow else ('shock', 'scared'), 0.7, seed=20,
      flashlight=True, arms=(8, -30), elbows=(0, -60), legs_walk=t*8 if not mine_glow else 0)

def _grid(cr, t, crossed_until, mine_glow=False):
    bg_fill(cr, '#26284f')
    random.seed(11)
    cols, rows = 5, 9
    cw, ch = 230, 205
    ox, oy = (W - cols*cw)/2 + 10, 70
    order = []
    for r in range(rows):
        rr = range(cols) if r % 2 == 0 else range(cols-1, -1, -1)
        for c in rr: order.append((c, r))
    mine = (2, 4)
    # path line
    cr.set_line_width(8); setc(cr, '#f3d27a', 0.9)
    pts = [(ox+c*cw+cw/2-5, oy+r*ch+ch/2) for c, r in order]
    n = int(crossed_until)
    if n > 0:
        cr.move_to(*pts[0])
        for p in pts[1:min(n+1, len(pts))]: cr.line_to(*p)
        cr.stroke()
    for idx, (c, r) in enumerate(order):
        x = ox + c*cw; y = oy + r*ch
        random.seed(idx*7+3); col = random.choice(HOUSE_COLS)
        if (c, r) == mine:
            g = 0.5 + 0.5*math.sin(t*8) if mine_glow else 0
            rrect(cr, x+10, y+10, cw-30, ch-30, 16); fs(cr, '#4fae6a', 7)
            if mine_glow:
                rrect(cr, x+2, y+2, cw-14, ch-14, 22); cr.set_line_width(10); setc(cr, '#ffd23f', 0.5+0.5*g); cr.stroke()
            continue
        rrect(cr, x+10, y+10, cw-30, ch-30, 16); fs(cr, col, 7)
        cr.set_line_width(5); setc(cr, OUT, 0.35); cr.move_to(x+20, y+ch/2-5); cr.line_to(x+cw-30, y+ch/2-5); cr.stroke()
        if idx < crossed_until:
            k = min(1, (crossed_until-idx)*1.5)
            if False: pass
            cr.set_line_width(14); setc(cr, '#e23b3b'); cr.set_line_cap(cairo.LINE_CAP_ROUND)
            cx, cy = x+cw/2-5, y+ch/2-5; d = 55*k
            cr.move_to(cx-d, cy-d); cr.line_to(cx+d, cy+d); cr.move_to(cx+d, cy-d); cr.line_to(cx-d, cy+d); cr.stroke()

def door(cr, x, y, w=330, h=620, color='#8a5a36', open_=0.0, sign_=False, dark=False):
    rrect(cr, x-w/2-20, y-h-20, w+40, h+20, 8); fs(cr, '#5a3a24')
    if open_ > 0:
        if dark:
            cr.rectangle(x-w/2, y-h, w, h); cr.set_source_rgb(0.02, 0.02, 0.04); cr.fill()
        else:
            g = cairo.LinearGradient(x-w/2, 0, x+w/2, 0)
            g.add_color_stop_rgba(0, 1, 1, 0.92, 1); g.add_color_stop_rgba(1, 1, 0.97, 0.8, 1)
            cr.rectangle(x-w/2, y-h, w, h); cr.set_source(g); cr.fill()
        ww = w*(1-open_*0.85)
        rrect(cr, x-w/2, y-h, ww, h, 6); fs(cr, color)
    else:
        rrect(cr, x-w/2, y-h, w, h, 6); fs(cr, color)
        for yy in (y-h+40, y-h/2+20):
            rrect(cr, x-w/2+40, yy, w-80, h/2-80, 8); cr.set_line_width(5); setc(cr, OUT, 0.6); cr.stroke()
        circ(cr, x+w/2-45, y-h/2, 18, '#e9b949', 5)
        if sign_:
            cr.save(); cr.translate(x+w/2-45, y-h/2+40); cr.rotate(0.08)
            cr.set_line_width(3); setc(cr, OUT); cr.move_to(0, -20); cr.line_to(-40, 20); cr.move_to(0, -20); cr.line_to(40, 20); cr.stroke()
            rrect(cr, -65, 20, 130, 110, 8); fs(cr, '#ffffff', 4)
            text(cr, 'NÃO', 0, 55, 30, '#e23b3b', lw=0); text(cr, 'PERTURBE', 0, 95, 22, OUT, lw=0)
            cr.restore()

def hallway(cr, t, glow=0.0):
    bg_fill(cr, '#232552')
    vx, vy = W/2, 900
    # walls
    cr.new_path(); cr.move_to(0, 0); cr.line_to(vx-170, vy-330); cr.line_to(vx-170, vy+170); cr.line_to(0, H); cr.close_path(); setc(cr, '#2f3170'); cr.fill()
    cr.new_path(); cr.move_to(W, 0); cr.line_to(vx+170, vy-330); cr.line_to(vx+170, vy+170); cr.line_to(W, H); cr.close_path(); setc(cr, '#2a2c66'); cr.fill()
    cr.new_path(); cr.move_to(0, H); cr.line_to(vx-170, vy+170); cr.line_to(vx+170, vy+170); cr.line_to(W, H); cr.close_path(); setc(cr, '#3a3268'); cr.fill()
    cr.new_path(); cr.move_to(W/2-250, H); cr.line_to(vx-60, vy+170); cr.line_to(vx+60, vy+170); cr.line_to(W/2+250, H); cr.close_path(); setc(cr, '#7d2f3d'); cr.fill()
    # frames on walls
    for (px, py, pw, ph) in ((90, 520, 150, 200), (860, 560, 130, 170)):
        rrect(cr, px, py, pw, ph, 6); fs(cr, '#d9a6b9', 6)
    # end door
    rrect(cr, vx-170, vy-330, 340, 500, 4); fs(cr, '#262350', 4)
    door(cr, vx, vy+170, 230, 430)
    if glow > 0:
        rings(cr, vx, vy-50, t, n=3, maxr=330*glow+80)

# ---------------------------------------------------------------- life helpers
def alive(t, seed=0, amp=1.0, arms=(8, -8), gest=False):
    r = seed*1.7
    tilt = (math.sin(t*1.1 + r)*0.05 + math.sin(t*2.3 + r)*0.015)*amp
    lean = math.sin(t*0.9 + r)*0.012*amp
    # eyes dart to a new spot every ~0.7s (smoothly)
    k = int(t/0.7 + r); u = ease((t/0.7 + r) % 1 / 0.25)
    def spot(i):
        rr = random.Random(i*31 + seed*7); return (rr.uniform(-0.9, 0.9), rr.uniform(-0.5, 0.4))
    a0, b0 = spot(k-1), spot(k)
    look = (a0[0] + (b0[0]-a0[0])*u, a0[1] + (b0[1]-a0[1])*u)
    sway = math.sin(t*1.3 + r)*3*amp
    breath = math.sin(t*2.2 + r)*0.008
    return dict(head_tilt=tilt, lean=lean, look=look, arms=(arms[0] + sway, arms[1] + sway), squash=breath, blink=blink_at(t, seed))

def cyc(lt, exprs, period=0.85):
    return exprs[int(lt/period) % len(exprs)]

def K(cr, x, y, s, t, lt, exprs=('neutral',), period=0.85, seed=0, amp=1.0, arms=(8, -8), gest=False, **over):
    kw = alive(t, seed, amp, arms)
    kw['expr'] = cyc(lt, exprs, period)
    kw.update(over)
    person(cr, x, y, s, **kw)

def talk_icon(cr, x, y, s, crossed=True):
    cr.save(); cr.translate(x, y); cr.scale(s, s)
    circ(cr, 0, 0, 120, '#ffffff', 10)
    rrect(cr, -78, -55, 156, 100, 40); fs(cr, '#8fd3ff', 6)
    cr.new_path(); cr.move_to(-40, 40); cr.line_to(-58, 78); cr.line_to(-10, 44); cr.close_path(); fs(cr, '#8fd3ff', 6)
    for dx in (-35, 0, 35): circ(cr, dx, -5, 10, OUT, 0)
    if crossed:
        cr.new_path(); cr.arc(0, 0, 120, 0, 2*math.pi); cr.set_line_width(20); setc(cr, '#e23b3b'); cr.stroke()
        cr.move_to(-85, -85); cr.line_to(85, 85); cr.set_line_width(20); cr.stroke()
    cr.restore()

def sign2(cr, x, y, t):
    cr.save(); cr.translate(x, y+150); cr.rotate(math.sin(t*1.7)*0.02); cr.translate(-x, -y-150)
    rrect(cr, x-10, y+150, 20, 330, 6); fs(cr, '#8a6a4a')
    rrect(cr, x-230, y-180, 460, 340, 24); fs(cr, '#fffaf0', 9)
    rrect(cr, x-210, y-160, 420, 300, 16); cr.set_line_width(5); setc(cr, '#e23b3b'); cr.stroke()
    talk_icon(cr, x, y-50, 0.72)
    text(cr, 'PROIBIDO', x, y+68, 54, '#e23b3b', lw=0)
    text(cr, 'FALAR', x, y+118, 40, OUT, lw=0)
    cr.restore()

def vignette(cr, a=0.6):
    g = cairo.RadialGradient(W/2, H/2, 300, W/2, H/2, 1250)
    g.add_color_stop_rgba(0, 0, 0, 0, 0); g.add_color_stop_rgba(1, 0, 0, 0, a)
    cr.rectangle(-200, -200, W+400, H+400); cr.set_source(g); cr.fill()

def placard(cr, x, y, s, label, col='#ffffff'):
    cr.save(); cr.translate(x, y); cr.scale(s, s)
    rrect(cr, -8, 0, 16, 140, 4); fs(cr, '#8a6a4a', 4)
    rrect(cr, -120, -90, 240, 110, 14); fs(cr, col, 6)
    text(cr, label, 0, -35, 56, OUT, lw=0)
    cr.restore()

# ---------------------------------------------------------------- scenes
def S_sign(cr, lt, t):
    town_bg(cr, t)
    sign2(cr, 560, 430, t)
    crowd = [(-40, 1500, 0.62, '#4cae9b', 'short', '#4a2f22', '#e2533b'), (180, 1460, 0.55, '#8d76c9', 'bob', '#2a1c16', None),
             (930, 1520, 0.68, '#2f3a66', 'short', '#4a2f22', '#e2533b'), (1100, 1460, 0.6, '#f19a5b', 'bob', '#6b3b22', None)]
    for i, (x, y, s, sh, hs, hc, cap) in enumerate(crowd):
        K(cr, x, y, s, t, lt+i*0.3, ('neutral', 'worried', 'confused', 'neutral'), 1.1, seed=i+2, shirt=sh, hairstyle=hs, hair=hc, cap=cap,
          skin='#e7b48c' if i % 2 else SKIN, mustache='#3a2a22' if i == 2 else None)
    if lt > 0.9: onoma(cr, 'PRIIII!', 820, 820, 120, lt-0.9, '#ffffff', rot=0.1)
    K(cr, 520, 1800, 0.95, t, lt, ('shock', 'worried', 'shock', 'scared'), 0.7, seed=1, arms=(18, -18), elbows=(-125, 125))

def S_missing(cr, lt, t):
    bg_fill(cr, '#e9dcc0')
    cr.set_line_width(3); setc(cr, '#d2c3a2')
    for yy in range(0, H, 90): cr.move_to(0, yy); cr.line_to(W, yy); cr.stroke()
    cr.save(); cr.translate(540, 270); cr.rotate(-0.04 + math.sin(t*2.2)*0.035); cr.translate(0, 550)
    rrect(cr, -340, -560, 680, 980, 10); fs(cr, '#fbf6e8', 8)
    text(cr, 'DESAPARECIDO', 0, -460, 82, '#e23b3b', lw=0)
    rrect(cr, -220, -380, 440, 470, 8); fs(cr, '#cfc6b0', 6)
    cr.save(); cr.rectangle(-220, -380, 440, 470); cr.clip()
    person(cr, 0, 380, 0.85, shirt='#8a8a8a', pants='#5a5a5a', hair='#5a4a40', skin='#d8c4a8', expr='happy', arms=(20, -20), hairstyle='short', mouth_open=0.8)
    cr.restore()
    text(cr, 'VISTO FALANDO', 0, 170, 46, OUT, lw=0)
    text(cr, '1955', 0, 260, 90, OUT, lw=0)
    cr.restore()
    circ(cr, 540, 270, 16, '#d1453b', 4)
    if lt > 1.5: tag(cr, 'HÁ 71 ANOS', 540, 1240, lt-1.5, bg='#e23b3b', fg='#ffffff', size=78)
    # kid peeking from the corner
    K(cr, 880, 2080, 0.9, t, lt, ('scared', 'worried', 'shock'), 0.8, seed=3)

def S_stage(cr, lt, t):
    stage_bg(cr, t)
    for i, c in enumerate(('#3fa7d6', '#e2533b', '#59cd90')):
        ph = t*3.2 + i*2.09
        circ(cr, W/2 + math.cos(ph)*170, 520 - abs(math.sin(ph))*260, 30, c, 5)
    K(cr, W/2, 1330, 1.0, t, lt, ('happy', 'happy', 'shock', 'happy', 'confused'), 0.7, seed=0,
      arms=(15, -15), elbows=(-110 + math.sin(t*6.4)*20, 110 - math.sin(t*6.4+1.5)*20))

def S_audience(cr, lt, t, jump_at=99, nunca_at=99):
    stage_bg(cr, t)
    setc(cr, '#000000', 0.35); cr.rectangle(-200, -200, W+400, H+400); cr.fill()
    rows = [(1120, 0.5), (1450, 0.6), (1840, 0.72)]
    labels = ['NOTA 10', 'UAU!', 'TOP!', '10', 'SHOW!']
    random.seed(3); k = 0
    show = lt < nunca_at
    for ri, (yy, s) in enumerate(rows):
        n = 5 - ri
        for i in range(n):
            k += 1
            x = (i + 0.5) * W/n + (40 if ri == 1 else 0)
            sh = random.choice(['#4cae9b', '#8d76c9', '#f19a5b', '#3fa7d6', '#e2533b', '#59cd90', '#f7c548'])
            hs = random.choice(['short', 'bob', 'spiky']); hc = random.choice(['#4a2f22', '#2a1c16', '#c98a3b']); sk = random.choice([SKIN, '#e7b48c', '#b57e55'])
            jb = 0
            cheer = show and lt > jump_at
            hold = (k % 2 == 0)
            if hold and show: arms, el = (8, -160), (0, 0)
            elif cheer: arms, el = (150, -150), (0, 0)
            elif show: arms, el = (18, -18), (-120 - math.sin(t*3+k)*10, 120 + math.sin(t*3+k)*10)
            else: arms, el = (8, -8), (0, 0)
            K(cr, x, yy, s, t, lt + k*0.2, ('happy', 'happy', 'shock', 'happy') if show else ('neutral', 'worried'), 0.8, seed=k, arms=arms, elbows=el, shirt=sh, hairstyle=hs, hair=hc, skin=sk)
            if hold and show:
                placard(cr, x + 118*s + math.sin(t*5+k)*6, yy + jb - 760*s + math.sin(t*6+k)*12, s*1.25, labels[k % 5], ['#ffffff', '#ffd23f', '#8fe3ff'][k % 3])
    if not show:
        setc(cr, '#000000', 0.35); cr.rectangle(-200, -200, W+400, H+400); cr.fill()
        q = lt - nunca_at
        kk = outback(q/0.25)
        cr.save(); cr.translate(W/2, 700); cr.scale(kk, kk); talk_icon(cr, 0, 0, 1.7, crossed=q > 0.3)
        cr.restore()
        if q > 0.3: tag(cr, 'NUNCA', W/2, 1130, q-0.3, bg='#e23b3b', fg='#ffffff', size=90)

def S_sleep(cr, lt, t, open_at=99):
    room_bg(cr, t, '23:58' if lt < 2.0 else '23:59')
    rrect(cr, 240, 820, 600, 260, 60); fs(cr, '#e8ecf8', 7)
    op = lt > open_at
    if op:
        K(cr, 540, 1560, 1.0, t, lt, ('shock', 'scared', 'worried', 'shock'), 0.7, seed=2)
    else:
        person(cr, 540, 1560 - abs(math.sin(t*1.6))*8, 1.0, expr='sleep', head_tilt=math.sin(t*1.2)*0.18, squash=math.sin(t*1.6)*0.015)
    sh = math.sin(t*1.6)*6 if not op else math.sin(t*30)*4
    cr.save(); cr.translate(sh, 0)
    cr.new_path(); cr.move_to(120, 1180); cr.curve_to(400, 1150 - sh*3, 700, 1150 + sh*3, 960, 1180); cr.line_to(990, H+50); cr.line_to(90, H+50); cr.close_path(); fs(cr, '#3c64c8', 8)
    cr.set_line_width(5); setc(cr, '#2d4ea3')
    for yy in (1320, 1480, 1640): cr.move_to(150, yy); cr.curve_to(400, yy-20, 700, yy+20, 930, yy); cr.stroke()
    cr.restore()
    circ(cr, 900, 1050, 70, '#b07a4a'); circ(cr, 850, 990, 26, '#b07a4a'); circ(cr, 950, 990, 26, '#b07a4a')
    circ(cr, 878, 1045, 7, OUT, 0); circ(cr, 922, 1045, 7, OUT, 0); ell(cr, 900, 1075, 20, 14, '#e8c9a0', 4)
    if not op:
        for i in range(3):
            p = ((lt*0.7 + i/3) % 1)
            text(cr, 'z', 720 + p*120, 700 - p*220, 50 + p*40, '#ffffff', lw=6, alpha=1-p)
    else:
        onoma(cr, '!', 760, 700, 180, lt-open_at, '#ffd23f', rot=0.1)

def S_tally(cr, lt, t):
    room_bg(cr, t, '00:01')
    cr.save(); cr.translate(540, 760); cr.rotate(math.sin(t*1.5)*0.015)
    rrect(cr, -300, -330, 600, 600, 18); fs(cr, '#fbf6e8', 8)
    rrect(cr, -300, -330, 600, 110, 18); fs(cr, '#e2533b', 8)
    text(cr, 'NOVEMBRO', 0, -275, 54, '#ffffff', lw=0)
    for d in range(28):
        cx = -240 + (d % 7)*80; cy = -170 + (d//7)*95
        text(cr, str(d+1), cx, cy, 34, OUT, lw=0)
        if d < int(lt*22):
            cr.set_line_width(8); setc(cr, '#e23b3b'); cr.move_to(cx-25, cy-25); cr.line_to(cx+25, cy+25); cr.move_to(cx+25, cy-25); cr.line_to(cx-25, cy+25); cr.stroke()
    cr.restore()
    K(cr, 540, 1800, 0.85, t, lt, ('angry', 'worried', 'confused', 'angry'), 0.6, seed=4)

def S_whisper(cr, lt, t):
    S_sleep(cr, 99, t, open_at=-1)
    setc(cr, '#05040f', 0.55); cr.rectangle(-200, -200, W+400, H+400); cr.fill()
    vignette(cr, 0.8)
    for i, (x, y, st) in enumerate(((260, 420, 0.1), (800, 600, 0.6), (400, 860, 1.1))):
        if lt > st:
            a = min(1, (lt-st)/0.3)*0.75
            text(cr, 'foge...', x + math.sin(t*3+i)*20, y + math.cos(t*2+i)*14, 80, '#b9b3ff', font='Anton', bold=False, lw=8, stroke='#140f2a', alpha=a, rot=-0.1+i*0.1)
    rings(cr, 540, 400, lt, color='#9a90ff', n=3, maxr=380)

def S_decide(cr, lt, t):
    room_bg(cr, t, '03:00')
    bed(cr, 420, 1560)
    K(cr, 640, 1720, 1.0, t, lt, ('determined', 'angry', 'determined', 'confused'), 0.7, seed=5, arms=(8, -15), elbows=(0, 125))

def S_flash(cr, lt, t):
    room_bg(cr, t, '03:00')
    sw = math.sin(t*2.5)*160
    g = cairo.LinearGradient(700, 1150, 1100, 700); g.add_color_stop_rgba(0, 1, 0.97, 0.75, 0.7); g.add_color_stop_rgba(1, 1, 0.97, 0.75, 0.0)
    cr.new_path(); cr.move_to(700, 1170); cr.line_to(1150, 600+sw); cr.line_to(1150, 1250+sw); cr.close_path(); cr.set_source(g); cr.fill()
    K(cr, 470, 1620, 1.0, t, lt, ('determined', 'confused', 'worried', 'determined'), 0.7, seed=6,
      arms=(8, -30), elbows=(0, -60 + math.sin(t*2.5)*12), flashlight=True, look=(0.9, math.sin(t*2.5)*0.6))
    if lt > 0.5: tag(cr, 'MISSÃO: ACHAR A VOZ', 540, 300, lt-0.5, size=54)

def S_map(cr, lt, t, start=0, rate=11, glow=False, label=None):
    grid_map(cr, t, start + lt*rate, mine_glow=glow, lt=lt)
    if label: tag(cr, label, 540, 180, lt, size=70)

def S_knock(cr, lt, t):
    town_bg(cr, t, night=True)
    setc(cr, '#000000', 0.25); cr.rectangle(-200, -200, W+400, H+400); cr.fill()
    rrect(cr, 120, 620, 840, 1100, 10); fs(cr, '#b8d4a0', 8)
    cr.set_line_width(4); setc(cr, '#9dbc84')
    for yy in range(660, 1700, 60): cr.move_to(120, yy); cr.line_to(960, yy); cr.stroke()
    door(cr, 380, 1700, 330, 700)
    rrect(cr, 660, 820, 200, 230, 8); fs(cr, '#ffe9a8', 7)
    k = 0
    for i, st in enumerate((0.15, 0.45, 0.75)):
        if lt > st: onoma(cr, 'TOC!', 330 + i*60, 1000 - i*110, 100, lt-st, '#ffffff', rot=-0.1 + i*0.1)
        if st - 0.1 < lt < st+0.05: k = 1
    K(cr, 700, 1820, 0.95, t, lt, ('determined', 'worried', 'confused'), 0.7, seed=7, arms=(40, -8), elbows=(60 - k*30, 0), look=(-1, 0))
    if lt > 1.0: tag(cr, 'SEU ARLINDO · 89 ANOS', 540, 470, lt-1.0, size=56)

def chalk_lines(t):
    words = [w for w in TL['words'] if w[1] >= ARL_V - 0.05]
    lines = [['VOZ?', 'AQUI?'], ['FAZ', '70', 'ANOS'], ['QUE', 'NINGUÉM'], ['FALA', 'NESSA'], ['RUA.']]
    flat = [x for l in lines for x in l]
    shown = sum(1 for w in words[:len(flat)] if w[1] <= t)
    out = []; c = 0
    for l in lines:
        cur = []
        for x in l:
            if c < shown: cur.append(x)
            c += 1
        out.append(' '.join(cur))
    return out

def S_arlindo(cr, lt, t):
    bg_fill(cr, '#4b3a6e', '#35295a')
    rrect(cr, 100, 300, 300, 380, 10); fs(cr, '#c9a24a', 7)
    rrect(cr, 130, 330, 240, 320, 6); fs(cr, '#e8d9b0', 0)
    rrect(cr, 700, 260, 300, 240, 10); fs(cr, '#6a8fd0', 7)
    K(cr, 300, 1780, 1.0, t, lt, ('confused', 'worried', 'confused', 'neutral', 'shock'), 0.8, seed=8, amp=1.0, arms=(8, -150), gest=False,
      shirt='#8a5fb0', pants='#5a4a6a', skin='#efc19c', hairstyle='old', glasses=True, mustache='#f4f4f4', nightcap='#7b6fd0')
    # chalkboard rises and is held in front of chest
    up = ease(lt/0.5)
    by = 1900 - up*1060 + math.sin(t*2.4)*10
    cr.save(); cr.translate(650, by); cr.scale(0.82, 0.82); cr.rotate(0.05 + math.sin(t*1.8)*0.03)
    rrect(cr, -360, -230, 720, 470, 22); fs(cr, '#8a5a36', 8)
    rrect(cr, -330, -200, 660, 410, 10); fs(cr, '#2f4a3a', 0)
    for i, ln in enumerate(chalk_lines(t)):
        if ln: text(cr, ln, 0, -150 + i*78, 62, '#f2f2ea', font='Poppins', lw=0)
    # chalk in hand
    cr.restore()
    for i, (bx, by2, st) in enumerate(((140, 1020, 0.2), (960, 1260, 0.6))):
        if lt > st:
            k = outback((lt-st)/0.25)
            cr.save(); cr.translate(bx, by2 + math.sin(t*3+i)*15); cr.scale(k, k); cr.rotate(-0.15 + i*0.3 + math.sin(t*2+i)*0.1)
            rrect(cr, -55, -60, 110, 120, 22); fs(cr, '#ffffff', 6)
            text(cr, '?', 0, 0, 90, OUT, lw=0)
            cr.restore()

def S_idea(cr, lt, t):
    town_bg(cr, t, night=True)
    setc(cr, '#000000', 0.3); cr.rectangle(-200, -200, W+400, H+400); cr.fill()
    K(cr, 540, 1950, 1.25, t, lt, ('happy', 'determined', 'happy', 'shock'), 0.7, seed=9, arms=(8, -30), elbows=(0, -60), flashlight=True)
    k = outback(lt/0.3)
    cr.save(); cr.translate(540, 330 + math.sin(t*4)*12); cr.scale(k, k); cr.rotate(math.sin(t*3)*0.08)
    for i in range(8):
        a = i*math.pi/4 + 0.2 + t*0.6
        cr.set_line_width(10); setc(cr, '#ffd23f'); cr.set_line_cap(cairo.LINE_CAP_ROUND)
        cr.move_to(math.cos(a)*120, math.sin(a)*120 - 20); cr.line_to(math.cos(a)*165, math.sin(a)*165 - 20); cr.stroke()
    circ(cr, 0, -20, 90, '#fff07a', 7); rrect(cr, -45, 60, 90, 60, 10); fs(cr, '#b9b9c9', 6)
    cr.restore()
    if lt > 1.9: tag(cr, 'FAMÍLIA BARBOSA · 6 FILHOS', 540, 620, lt-1.9, size=52, bg='#59cd90')

def S_ear(cr, lt, t):
    bg_fill(cr, '#4f8a5a')
    cr.set_line_width(5); setc(cr, '#447a4e')
    for yy in range(0, H, 70): cr.move_to(0, yy); cr.line_to(W, yy); cr.stroke()
    door(cr, 130, 1750, 520, 1500)
    K(cr, 640 - ease(lt/0.5)*40, 1980, 1.45, t, lt, ('worried', 'confused', 'shock', 'worried'), 0.8, seed=10,
      lean=-0.18 + math.sin(t*1.2)*0.015, look=(-1, math.sin(t*1.5)*0.3))
    if lt > 1.5:
        onoma(cr, 'RONC...', 780, 380 + math.sin(t*4)*20, 120, lt-1.5, '#ffffff', rot=0.08)
        for i in range(3):
            p = ((lt*0.6 + i/3) % 1)
            text(cr, 'Z', 300 + p*80, 500 - p*200, 60+p*50, '#ffffff', lw=8, alpha=1-p)

def S_home(cr, lt, t):
    bg_fill(cr, '#1d2050', '#2a2c66')
    rrect(cr, 60, 380, 960, 1600, 10); fs(cr, '#f2b8c6', 8)
    rrect(cr, 640, 560, 250, 260, 8); fs(cr, '#ffe9a8', 7)
    cr.set_line_width(6); setc(cr, OUT); cr.move_to(765, 560); cr.line_to(765, 820); cr.move_to(640, 690); cr.line_to(890, 690); cr.stroke()
    door(cr, 460, 1900, 340, 760, open_=min(1, lt/1.0)*0.9)
    rrect(cr, 60, 330, 960, 60, 10); fs(cr, '#c4574a', 7)
    p = ease((lt-0.3)/1.4)
    kid(cr, 470, 2080 - p*80, 1.15 - p*0.12, back=True, arms=(8 + math.sin(t*5)*10, -8 + math.sin(t*5)*10),
        legs_walk=t*5 if 0.3 < lt < 1.7 else 0, head_tilt=math.sin(t*1.5)*0.04)
    if lt > 0.2 and lt < 1.2: tag(cr, 'A MINHA', 540, 220, lt-0.2, bg='#59cd90', size=70)

def S_hall(cr, lt, t):
    hallway(cr, t, glow=0.7)
    p = ease(lt/3.0)
    # creeping on tiptoes, looking around
    kid(cr, W/2, 1950 - p*600, 0.95 - p*0.45, back=True, legs_walk=t*4,
        arms=(16 + math.sin(t*4)*6, -16 + math.sin(t*4)*6), elbows=(-30, 30), head_tilt=math.sin(t*1.2)*0.12)
    if lt > 0.8: onoma(cr, '...', 540, 500 + math.sin(t*3)*15, 120, lt-0.8, '#b9b3ff', rot=0)

def S_door(cr, lt, t, mode='listen'):
    bg_fill(cr, '#2c2d66')
    rrect(cr, 760, 220, 200, 250, 8); fs(cr, '#e8b6c8', 6)
    door(cr, 330, 1850, 520, 1500)
    rings(cr, 330, 900, t, color='#b9b3ff', n=2, maxr=260)
    if mode == 'listen':
        K(cr, 780, 1900, 1.0, t, lt, ('scared', 'worried', 'shock', 'scared'), 0.7, seed=11, look=(-0.9, -0.2), arms=(18, -18), elbows=(-120, 120))
    elif mode == 'foge':
        setc(cr, '#05040f', 0.45); cr.rectangle(-200, -200, W+400, H+400); cr.fill()
        K(cr, 780, 1900, 1.0, t, lt, ('scared', 'shock', 'scared'), 0.6, seed=12, look=(-0.9, -0.1), arms=(20, -20), elbows=(-140, 140), shake=math.sin(t*45)*3)
        fw = [w for w in TL['words'] if w[0].lower().startswith('foge')]
        pos = [(330, 520, -0.12), (560, 820, 0.08), (420, 1120, -0.04)]
        for i, w in enumerate(fw[:3]):
            if t >= w[1]:
                q = t - w[1]; x, y, r = pos[i]
                j = math.sin(t*50+i)*5
                onoma(cr, 'FOGE...', x + j, y + math.cos(t*47+i)*5, 150 + i*25, q, ['#d9d4ff', '#ff8a8a', '#ff3b3b'][i], rot=r)
        vignette(cr, 0.85)
    else:  # grab
        K(cr, 780, 1900, 1.0, t, lt, ('worried', 'scared', 'determined', 'scared'), 0.7, seed=13, arms=(70 + ease(lt/0.6)*10, -8), elbows=(0, 0),
          look=(-0.8, -0.2), shake=math.sin(t*40)*2)
        vignette(cr, 0.6)

def S_open(cr, lt, t):
    bg_fill(cr, '#1c1d48')
    door(cr, 330, 1850, 520, 1500, open_=ease(lt/1.2), dark=True)
    if lt > 1.0:
        a = min(1, (lt-1.0)/0.3)
        bl = ((lt*1.3) % 1.6) < 0.1
        for ex in (250, 340):
            if not bl:
                cr.new_path(); cr.save(); cr.translate(ex, 760); cr.scale(26, 14); cr.arc(0, 0, 1, 0, 2*math.pi); cr.restore()
                setc(cr, '#fff6a0', a); cr.fill()
    K(cr, 780, 1900, 1.0, t, lt, ('shock', 'scared', 'shock'), 0.6, seed=14, arms=(20, -20), elbows=(-140, 140), look=(-1, -0.4), shake=math.sin(t*50)*3)
    vignette(cr, 0.8)

def S_end(cr, lt, t):
    bg_fill(cr, '#0d0c18')
    if lt > 0.2:
        k = outback((lt-0.2)/0.3)
        cr.save(); cr.translate(W/2, 780); cr.scale(k, k); cr.rotate(math.sin(t*2)*0.03)
        text(cr, 'PARTE 2', 0, -60, 150, '#ffd23f', font='Anton', bold=False, lw=14)
        text(cr, 'AMANHÃ', 0, 100, 120, '#ffffff', font='Anton', bold=False, lw=12)
        cr.restore()
    if lt > 0.8:
        k = outback((lt-0.8)/0.3) * (1 + 0.04*math.sin(t*6))
        cr.save(); cr.translate(W/2, 1150); cr.scale(k, k)
        rrect(cr, -390, -75, 780, 150, 75); fs(cr, '#e23b3b', 8)
        text(cr, 'SEGUE PRA NÃO PERDER', 0, 2, 56, '#ffffff', lw=0)
        cr.restore()

def wt(word, after=0.0):
    for w, s, e in TL['words']:
        if s >= after and w.lower().startswith(word.lower()): return s
    raise KeyError(word)

END = MK['end_speech']
ARL_V = wt('Voz', 27)
t_aud = wt('a', 7.0)
SC = [
    (0.0, S_sign),
    (wt('O', 1.3), S_missing),
    (wt('então'), S_stage),
    (t_aud, lambda cr, lt, t: S_audience(cr, lt, t, jump_at=wt('pula')-t_aud, nunca_at=wt('mas', 10)-t_aud)),
    (wt('Só'), lambda cr, lt, t: S_sleep(cr, lt, t, open_at=wt('eu', 14.3)-wt('Só'))),
    (wt('toda', 15), S_tally),
    (wt('sussurrando'), S_whisper),
    (wt('Então', 17.5), S_decide),
    (wt('Peguei'), S_flash),
    (wt('Rua'), lambda cr, lt, t: S_map(cr, lt, t, 0, 7, label='RUA POR RUA')),
    (wt('Batindo'), S_knock),
    (wt('ele', 26), S_arlindo),
    (wt('Aí'), S_idea),
    (wt('encostei'), S_ear),
    (wt('nada'), lambda cr, lt, t: S_map(cr, lt, t, 20, 12)),
    (wt('Foi', 38), lambda cr, lt, t: S_map(cr, lt, t, 44, 0, glow=True, label='PULEI UMA CASA')),
    (wt('voltei'), S_home),
    (wt('e', wt('devagar')), S_hall),
    (wt('uma', wt('pais')), lambda cr, lt, t: S_door(cr, lt, t, 'listen')),
    (MK['foge_start'] - 0.1, lambda cr, lt, t: S_door(cr, lt, t, 'foge')),
    (wt('peguei', 50), lambda cr, lt, t: S_door(cr, lt, t, 'grab')),
    (END - 0.1, S_open),
    (END + 2.2, S_end),
]
TOTAL = END + 4.6

FIX = {'a@3.3': 'HÁ', 'anos,': 'ANOS.', 'então': 'ENTÃO,', 'estou': 'TÔ', 'falar@10.6': 'FALAR?', 'voz@15.2': 'VOZ.', 'noite,@15.8': 'NOITE.',
       'Batindo': 'BATI', 'a@26.5': 'NA', 'louzinha': 'LOUSINHA', 'escreveu.': 'ESCREVEU:', 'Voz,': 'VOZ?', 'aqui,': 'AQUI?',
       'certeza,': 'CERTEZA:', 'filhos,': 'FILHOS.', 'nada,': 'NADA.', 'percebi,': 'PERCEBI...', 'minha,': 'MINHA.', 'voltei,': 'VOLTEI.',
       'devagar,': 'DEVAGAR...', 'barulho,': 'BARULHO...', 'pais,': 'PAIS.', 'voz@48.7': 'VOZ...', 'dizendo,': 'DIZENDO:', 'Foge!': 'FOGE...',
       'maçaneta,': 'MAÇANETA...', 'porta.': 'PORTA...', 'bairro,': 'BAIRRO.', 'cadeira,': 'CADEIRA...'}
DROP = {'a@8.2'}

# ---------------------------------------------------------------- captions
words = []
for w, s, e in TL['words']:
    key = f'{w}@{s:.1f}'
    if key in DROP: continue
    if w == 'ar': words.append(['ARLINDO,', s, e]); continue
    if w == 'lindo,': words[-1][2] = e; continue
    words.append([FIX.get(key, FIX.get(w, w.upper())), s, e])
chunks = []; cur = []
for w in words:
    cur.append(w)
    if len(cur) == 3 or w[0][-1] in '.,?:!':
        chunks.append(cur); cur = []
if cur: chunks.append(cur)
ORANGE = {'FALAR', 'FALOU', 'FALA', 'VOZ', 'LANTERNA', 'BARBOSA', 'ARLINDO', 'MINHA', 'PAIS', 'PORTA', 'SHOW', 'TALENTOS', 'LOUSINHA', 'NOITE', 'MAÇANETA', 'QUARTO', 'SUSSURRANDO', 'BARULHO'}
RED = {'PROIBIDO', 'DESAPARECEU', 'NUNCA', '71', 'FOGE'}
def core(w): return ''.join(ch for ch in w if ch.isalnum() or ch in 'ÁÉÍÓÚÂÊÔÃÕÇ')

def captions(cr, t):
    if t > END: return
    for ci, ch in enumerate(chunks):
        st = ch[0][1]; en = chunks[ci+1][0][1] if ci+1 < len(chunks) else END
        if ch[-1][2] + 0.9 < en: en = ch[-1][2] + 0.9
        if st <= t < en:
            vis = [w for w in ch if w[1] <= t + 0.02]
            size = 84
            ws = [text_w(cr, w[0] + ' ', size) for w in ch]
            total = sum(ws) - text_w(cr, ' ', size)
            if total > W - 120: size = size*(W-120)/total; ws = [text_w(cr, w[0] + ' ', size) for w in ch]; total = sum(ws) - text_w(cr, ' ', size)
            x = W/2 - total/2; y = 1565
            for w, wd in zip(ch, ws):
                if w in vis:
                    c = core(w[0]); col = '#ff9f1c' if c in ORANGE else ('#ff4b4b' if c in RED else '#ffffff')
                    k = outback((t - w[1])/0.12) if t - w[1] < 0.12 else 1
                    cr.save(); cr.translate(x, y); cr.scale(k, k)
                    text(cr, w[0], 0, 0, size, col, anchor='l', lw=14, stroke='#1a1428')
                    cr.restore()
                x += wd
            return

# ---------------------------------------------------------------- render loop
def frame(t):
    surf = cairo.ImageSurface(cairo.FORMAT_RGB24, W, H)
    cr = cairo.Context(surf)
    idx = max(i for i, (st, _) in enumerate(SC) if st <= t)
    st, fn = SC[idx]
    lt = t - st
    cr.save()
    # camera: entrance pop (4 frames) + slow drift + handheld sway
    pop = 1.0 + 0.12*(1 - ease(lt/0.13)) if idx > 0 else 1.0
    z = pop * (1.0 + 0.025*lt)
    sx = 0; sy = 0
    cr.translate(W/2 + sx, H/2 + sy); cr.scale(z, z); cr.translate(-W/2, -H/2)
    fn(cr, lt, t)
    cr.restore()
    captions(cr, t)
    return surf

if __name__ == '__main__':
    mode = sys.argv[1]
    if mode == 'still':
        for tt in sys.argv[2:]:
            frame(float(tt)).write_to_png(f'{OUTDIR}/s_{float(tt):05.1f}.png')
    else:
        a, b = float(sys.argv[2]), float(sys.argv[3]); outf = sys.argv[4]
        p = subprocess.Popen(['ffmpeg', '-v', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', 'bgra', '-s', f'{W}x{H}', '-r', str(FPS), '-i', '-',
                              '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '18', '-pix_fmt', 'yuv420p', outf], stdin=subprocess.PIPE)
        n0, n1 = int(round(a*FPS)), int(round(b*FPS))
        for n in range(n0, n1):
            s = frame(n/FPS); p.stdin.write(bytes(s.get_data()))
        p.stdin.close(); p.wait()
