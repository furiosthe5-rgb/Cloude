import json,numpy as np,soundfile as sf
W=json.load(open("words.json")); SR=44100
def load(f):
    a,_=sf.read(f); return a if a.ndim==1 else a.mean(1)
A,C,F=load("a.wav"),load("c.wav"),load("f.wav")
wa,wc,wf=W["a.wav"],W["c.wav"],W["f.wav"]
def split(ws,word):
    for i,(w,s,e) in enumerate(ws):
        if w.lower().startswith(word): return (e+ws[i+1][1])/2
pa=split(wa,"sussurrando"); pc=split(wc,"dizendo")
plan=[(A,wa,0,pa,1.7,"whisper1"),(A,wa,pa,None,0.3,None),(C,wc,0,pc,0.15,"foge"),(F,wf,0,None,0.35,"foge_end"),(C,wc,pc,None,0.0,None)]
out=[];words=[];marks={};t=0.0
for a,ws,t0,t1,gap,mark in plan:
    seg=a[int(t0*SR):int(t1*SR) if t1 else None]
    words+=[(w,round(s-t0+t,3),round(e-t0+t,3)) for w,s,e in ws if s>=t0-0.01 and (t1 is None or s<t1)]
    if mark=="foge_end": pass
    out.append(seg); t+=len(seg)/SR
    if mark: marks[mark]=round(t,3)
    out.append(np.zeros(int(gap*SR))); t+=gap
marks["foge_start"]=marks["foge"]+0.15  # foge clip starts after 0.15 gap
marks["end_speech"]=round(t,3)
sf.write("narr.wav",np.concatenate(out),SR)
json.dump({"words":words,"marks":marks,"dur":t},open("timeline.json","w"),ensure_ascii=False)
print(marks)
