import sys,json,subprocess,numpy as np
from faster_whisper import WhisperModel
m=WhisperModel("small",device="cpu",compute_type="int8")
out={}
for f in sys.argv[1:]:
    raw=subprocess.run(["ffmpeg","-v","error","-i",f,"-ac","1","-ar","16000","-f","s16le","-"],capture_output=True).stdout
    a=np.frombuffer(raw,np.int16).astype(np.float32)/32768
    segs,_=m.transcribe(a,language="pt",word_timestamps=True)
    out[f]=[(w.word.strip(),round(w.start,2),round(w.end,2)) for s in segs for w in s.words]
json.dump(out,open("words.json","w"),ensure_ascii=False)
for f,ws in out.items(): print(f, " ".join(f"{w}@{s}" for w,s,e in ws))
