import json,subprocess
W=json.load(open('words.json'))
gaps=[(18.93,1.1,'trim1'),(22.80,2.75,'kelvin'),(27.42,1.4,'nina'),(35.95,2.3,'cida'),(45.12,1.6,'trim2')]
def off(t): return t+sum(g for c,g,_ in gaps if t>=c)
fix={'Trin,':'Trim.','Trin':'Trim','Sida,':'Cida,','Sida.':'Cida.','10':'DEZ','8':'OITO','5':'CINCO','6':'SEIS','92':'92','não':'no','eu,':'eu...','coisa,':'coisa:','vê,':'vê:','fala,':'fala:','sorriu.':'sorriu:','perguntei,':'perguntei:','robô,':'robô.','despertador,':'despertador.','braços,':'braços.'}
out=[]
for s,e,w in W:
    ww=fix.get(w,w)
    if w=='acorda' and s>26: ww='dá corda'
    if w=='não' and s>58: ww='não'
    out.append([round(off(s),3),round(off(e),3),ww])
files=[];prev=0
for c,g,_ in gaps: files+= [('narr',prev,c),('sil',g,None)]; prev=c
files.append(('narr',prev,None))
fl=[]
for n,(k,a,b) in enumerate(files):
    if k=='narr': fl.append(f"[0:a]atrim=start={a}"+(f":end={b}" if b else "")+f",asetpts=PTS-STARTPTS[p{n}]")
    else: fl.append(f"anullsrc=r=44100:cl=mono,atrim=duration={a}[p{n}]")
fl.append("".join(f"[p{i}]" for i in range(len(files)))+f"concat=n={len(files)}:v=0:a=1[o]")
subprocess.run(['ffmpeg','-v','error','-y','-i','../audio/narr_fast.wav','-filter_complex',";".join(fl),'-map','[o]','-ac','1','-ar','44100','narr_timed.wav'],check=True)
dur=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0','narr_timed.wav']))
G={tag:round(c+sum(g2 for c2,g2,_ in gaps if c2<c),3) for c,g,tag in gaps}
json.dump({'words':out,'gaps':G,'dur':round(dur+1.6,2)},open('timeline.json','w'),ensure_ascii=False)
print(dur,G)
print(" ".join(f"{a}:{w}" for a,b,w in out))
