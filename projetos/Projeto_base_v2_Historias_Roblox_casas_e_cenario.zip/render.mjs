import puppeteer from 'puppeteer-core';
import http from 'http';import fs from 'fs';import path from 'path';import {spawn} from 'child_process';
const root=process.cwd();
const srv=http.createServer((q,r)=>{const p=path.join(root,decodeURIComponent(q.url.split('?')[0]));fs.readFile(p,(e,d)=>{if(e){r.writeHead(404);r.end();return;}r.writeHead(200,{'Content-Type':p.endsWith('.js')?'text/javascript':p.endsWith('.html')?'text/html':p.endsWith('.json')?'application/json':'application/octet-stream'});r.end(d);});}).listen(0);
const port=srv.address().port;
const browser=await puppeteer.launch({executablePath:'/usr/bin/google-chrome',headless:true,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist','--disable-dev-shm-usage']});
const page=await browser.newPage();await page.setViewport({width:1080,height:1920});
page.on('console',m=>console.log('PAGE',m.text()));page.on('pageerror',e=>console.log('ERR',e.message));
await page.goto(`http://localhost:${port}/scene.html`);await page.waitForFunction('window.ready===true',{timeout:60000});
const mode=process.argv[2];
if(mode==='frames'){fs.mkdirSync('test',{recursive:true});for(const t of process.argv.slice(3).map(Number)){const d=await page.evaluate(t=>renderFrame(t),t);fs.writeFileSync(`test/f_${t}.jpg`,Buffer.from(d.split(',')[1],'base64'));console.log('frame',t);}}
else if(mode==='shots'){const shots=await page.evaluate(()=>shotList);fs.mkdirSync('shots',{recursive:true});const only=process.argv[3]?process.argv[3].split(',').map(Number):null;
  for(let i=0;i<shots.length;i++){if(only&&!only.includes(i))continue;const [t0,t1]=shots[i];const f0=Math.round(t0*30),f1=Math.round(t1*30);const tmp=`shots/s${String(i).padStart(2,'0')}.tmp.mp4`;
    const ff=spawn('ffmpeg',['-v','error','-y','-f','image2pipe','-c:v','mjpeg','-framerate','30','-i','-','-c:v','libx264','-crf','18','-preset','veryfast','-pix_fmt','yuv420p','-r','30',tmp]);
    const st=Date.now();for(let f=f0;f<f1;f++){const d=await page.evaluate(t=>renderFrame(t),f/30);if(!ff.stdin.write(Buffer.from(d.split(',')[1],'base64')))await new Promise(r=>ff.stdin.once('drain',r));}
    ff.stdin.end();const code=await new Promise(r=>ff.on('close',r));if(code===0)fs.renameSync(tmp,tmp.replace('.tmp',''));console.log('shot',i,f1-f0,'frames',((Date.now()-st)/1000).toFixed(1)+'s',code);}}
await browser.close();srv.close();
